﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Media;
using System.Xml.Linq;
using variant26.DataBase;

namespace variant26.ViewModels
{
    public class ProductViewModel
    {
        public ProductViewModel(Product product)
        {
            id = product.id;
            Article = product.Article;
            Name = product.Name;
            Price = product.Price;
            Discount = product.Discount;
            AmountinStock = product.AmountinStock;
            Description = product.Description;
            Photo = product.Photo;
            Category = product.Category;
            Producer = product.Producer;
            Provider = product.Provider;
            Unit = product.Unit;

            GetBackground();
            GetPhoto();
            GetPrice(); 
        }
        public int id { get; set; }
        public string Article { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public decimal OldPrice { get; set; }

        public decimal Discount { get; set; }
        public decimal AmountinStock { get; set; }
        public string Description { get; set; }
        public string Photo { get; set; }

        public Category Category { get; set; }
        public Producer Producer { get; set; }
        public Provider Provider { get; set; }
        public Unit Unit { get; set; }
        public Brush Background { get; set; }
        private void GetBackground()
        {
            if (Discount >= 15)
            {
                Background = (Brush)new BrushConverter().ConvertFromString("#2e8b57");
                return;
            } else if (AmountinStock == 0)
            {
                Background = Brushes.LightBlue;
                return;
            }
            else
            {
                Background = (Brush)new BrushConverter().ConvertFromString("#7fff00");
                return;
            }
        }
        private void GetPhoto()
        {
            if (!string.IsNullOrEmpty(Photo) || Photo != "")
                return;
            Photo = "/Res/picture.png";
        }
        private void GetPrice()
        {
            if (Discount == 0)
                return;
            OldPrice = Price;
            Price = OldPrice * (1 - Discount / 100);
        }
    }
}
