﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using variant26.DataBase;

namespace variant26.ApplicationData
{
    internal class AppConnect
    {
        public static variant26Entities model0db;
    }
}
