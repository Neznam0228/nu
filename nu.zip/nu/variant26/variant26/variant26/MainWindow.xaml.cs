﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using variant26.ApplicationData;
using variant26.DataBase;
using variant26.DataBase.Helpers;
using variant26.DataBase.Statics;

namespace variant26
{
    public partial class MainWindow : Window
    {
        private variant26Entities model0db = new variant26Entities();
        private MessageHelper messageHelper = new MessageHelper();
        public MainWindow()
        {
            InitializeComponent();
        }


        private void TextBlock_MouseDown(object sender, MouseButtonEventArgs e)
        {
            new ProductWindow().Show();
            Close();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string login = LoginEnter.Text;
            string password = PasswordEnter.Password;

            var user = model0db.User.Where(u => u.Login == login && u.Password == password).FirstOrDefault();

            if (user == null)
            {
                messageHelper.ShowError("Введён неправильный логин или пароль");
                return;
            }
            else
            {
                CurrentSesion.CurrentUser = user;
                new ProductWindow().Show();
                Close();
            }
        }
    }
}
