﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using variant26.DataBase;
using variant26.DataBase.Helpers;
using variant26.DataBase.Statics;
using variant26.ViewModels;

namespace variant26
{
    /// <summary>
    /// Логика взаимодействия для ProductWindow.xaml
    /// </summary>
    public partial class ProductWindow : Window
    {
        private variant26Entities model0db = new variant26Entities();
        private MessageHelper messageHelper = new MessageHelper();
        private List<ProductViewModel> _productViewModels = new List<ProductViewModel>();
        private User _currentUser;

        private string[] _sortingTypes = new string[]
        {
            "По умолчанию",
            "По убыванию",
            "По возрастанию"
        };
        //Используется список строк, а не массив потому что массив строк нельзя расширить, список можно расширить внутри кода
        private List<string> _filteringTypes = new List<string>()
        {
            "Все поставщики"
        };

        public ProductWindow()
        {
            InitializeComponent();
            LoadProducts();
            LoadData();
            LoadUI();
        }

        private void LoadUI()
        {
            User user = CurrentSesion.CurrentUser;
            if (user == null || user.RoleId == 3)
            {
                Adminpanel.Visibility = Visibility.Collapsed;
            }
            else if (user.RoleId == 1)
            {
                CreateButton.Visibility = Visibility.Visible;
            }
        }

        private void LoadData()
        {
            SortingComboBox.ItemsSource = _sortingTypes;
            SortingComboBox.SelectedIndex = 0;

            var provider = model0db.Provider.ToList();
            foreach (var p in provider)
                _filteringTypes.Add(p.name);
            FilteringComboBox.ItemsSource = _filteringTypes;
            FilteringComboBox.SelectedIndex = 0;

            User user = CurrentSesion.CurrentUser;
            if (user != null)
                FullUserName.Text = $"{user.Surname} {user.Name} {user.Patronmic}";
        }

        private void LoadProducts()
        {
            var products = model0db.Product.ToList();
            foreach (var p in products)
                _productViewModels.Add(new ProductViewModel(p));

            ProductList.ItemsSource = _productViewModels;
        }
        private void UpdateProducts()
        {
            ProductList.ItemsSource = _productViewModels;
        }

        private void LogOutButton_Click(object sender, RoutedEventArgs e)
        {
            CurrentSesion.CurrentUser = null;
            new MainWindow().Show();
            Close();
        }

        private void SearcingTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            string searchingText = SearcingTextBox.Text;
            _productViewModels = model0db.Product
                .Where(p =>
                    p.Category.Name.ToLower().Contains(searchingText) ||
                    p.Name.ToLower().Contains(searchingText) ||
                    p.Description.ToLower().Contains(searchingText) ||
                    p.Provider.name.ToLower().Contains(searchingText) ||
                    p.Producer.Name.ToLower().Contains(searchingText) ||
                    p.Unit.Name.ToLower().Contains(searchingText)
                )
                .ToList()
                .Select(p => new ProductViewModel(p))
                .ToList();
            UpdateProducts();
        }

        private void SortingComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int sortingType = SortingComboBox.SelectedIndex;
            if (sortingType == 0)
            {
                LoadProducts();
            }
            else if (sortingType == 1)
            {
                _productViewModels = _productViewModels.OrderByDescending(p => p.AmountinStock).ToList();
                UpdateProducts();
            }
            else if (sortingType == 2)
            {
                _productViewModels = _productViewModels
                    .OrderBy(p => p.AmountinStock).ToList();
                UpdateProducts();
            }
        }
        private void FilteringComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string filteringText = FilteringComboBox.SelectedValue.ToString();
            if (filteringText == "Все поставщики")
            {
                LoadProducts();
                return;
            }
            _productViewModels = _productViewModels
                .Where(p => p.Provider.name == filteringText)
                .ToList();
            UpdateProducts();
        }

        private void CreateButton_Click(object sender, RoutedEventArgs e)
        {
            new AddEditProductWindow(null).Show();
            Close();
        }

        private void Border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            // Обновляем пользователя из сессии на случай, если поле устарело
            if (_currentUser == null)
                _currentUser = CurrentSesion.CurrentUser;

            if (_currentUser == null)
            {
                messageHelper.ShowError("Пользователь не авторизован");
                return;
            }

            if (_currentUser.RoleId != 1)
            {
                messageHelper.ShowWarning("Только администратор может редактировать товары");
                return;
            }

            var border = sender as Border;
            if (border?.DataContext is ProductViewModel product)
            {
                new AddEditProductWindow(product.id).Show();
                Close();
            }
        }

        private void OrdersButton_Click(object sender, RoutedEventArgs e)
        {
            if (CurrentSesion.CurrentUser == null)
            {
                messageHelper.ShowError("Необходима авторизация");
                return;
            }
            new OrdersWindow().Show();
        }
    }
}

