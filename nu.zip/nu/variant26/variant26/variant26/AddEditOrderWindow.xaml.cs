﻿using System;
using System.Linq;
using System.Windows;
using variant26.DataBase;
using variant26.DataBase.Helpers;

namespace variant26
{
    public class PickUpPointDisplay
    {
        public int Id { get; set; }
        public string Address { get; set; }
    }

    public partial class AddEditOrderWindow : Window
    {
        private readonly variant26Entities _db = new variant26Entities();
        private readonly MessageHelper _messageHelper = new MessageHelper();
        private readonly bool _isEditing;
        private Order _order;
        private PickUpPointDisplay[] _pickUpPoints;
        private User[] _users;
        private OrderStatus[] _statuses;

        public AddEditOrderWindow(int? id)
        {
            InitializeComponent();
            LoadComboBoxes();

            if (id.HasValue)
            {
                _isEditing = true;
                _order = _db.Order.Find(id.Value);
                if (_order == null)
                {
                    _messageHelper.ShowError("Заказ не найден");
                    Close();
                    return;
                }
                FillData();
            }
            else
            {
                _isEditing = false;
                _order = new Order();
                CreationDatePicker.SelectedDate = DateTime.Today;
            }
        }

        private void LoadComboBoxes()
        {
            // Пользователи
            _users = _db.User.Where(u => u.RoleId == 3).ToArray();
            UserCombo.ItemsSource = _users;
            UserCombo.DisplayMemberPath = "Surname";

            // Статусы – теперь тоже через SelectedItem
            _statuses = _db.OrderStatus.ToArray();
            StatusCombo.ItemsSource = _statuses;
            StatusCombo.DisplayMemberPath = "Name";

            // Пункты выдачи
            var pointsFromDb = _db.PickUpPoint.ToList();
            _pickUpPoints = pointsFromDb.Select(p => new PickUpPointDisplay
            {
                Id = p.id,
                Address = $"{p.City}, {p.Street}, {p.Building}"
            }).ToArray();
            PickUpPointCombo.ItemsSource = _pickUpPoints;
            PickUpPointCombo.DisplayMemberPath = "Address";
        }

        private void FillData()
        {
            // Поиск выбранных элементов по Id
            UserCombo.SelectedItem = _users.FirstOrDefault(u => u.id == _order.UserId);
            StatusCombo.SelectedItem = _statuses.FirstOrDefault(s => s.id == _order.StatusId);
            PickUpPointCombo.SelectedItem = _pickUpPoints.FirstOrDefault(p => p.Id == _order.PickUpPointId);

            CreationDatePicker.SelectedDate = _order.CreationDate;
            DeliveryDatePicker.SelectedDate = _order.DeliveryDate;
            ReceiptCodeBox.Text = _order.ReceiptCode;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (!ValidateInput()) return;

            _order.UserId = ((User)UserCombo.SelectedItem).id;
            _order.StatusId = ((OrderStatus)StatusCombo.SelectedItem).id;
            _order.PickUpPointId = ((PickUpPointDisplay)PickUpPointCombo.SelectedItem).Id;
            _order.CreationDate = CreationDatePicker.SelectedDate.Value.Date;
            _order.DeliveryDate = (DateTime)(DeliveryDatePicker.SelectedDate?.Date); 
            _order.ReceiptCode = ReceiptCodeBox.Text.Trim();

            try
            {
                if (!_isEditing)
                    _db.Order.Add(_order);
                _db.SaveChanges();
                _messageHelper.ShowInfo(_isEditing ? "Заказ обновлён" : "Заказ создан");
                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                Exception innerEx = ex.InnerException;
                while (innerEx?.InnerException != null)
                    innerEx = innerEx.InnerException;
                _messageHelper.ShowError($"Ошибка БД: {innerEx?.Message ?? ex.Message}");
            }
        }
        private bool ValidateInput()
        {
            if (UserCombo.SelectedItem == null)
            {
                _messageHelper.ShowError("Выберите пользователя");
                return false;
            }
            if (StatusCombo.SelectedItem == null)
            {
                _messageHelper.ShowError("Выберите статус");
                return false;
            }
            if (PickUpPointCombo.SelectedItem == null)
            {
                _messageHelper.ShowError("Выберите пункт выдачи");
                return false;
            }
            if (CreationDatePicker.SelectedDate == null)
            {
                _messageHelper.ShowError("Укажите дату заказа");
                return false;
            }
            if (string.IsNullOrWhiteSpace(ReceiptCodeBox.Text) || ReceiptCodeBox.Text.Length != 4)
            {
                _messageHelper.ShowError("Код получения должен быть 4 символа");
                return false;
            }
            return true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}