﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using variant26.DataBase;
using variant26.DataBase.Helpers;
using variant26.DataBase.Statics;

namespace variant26
{
    public partial class OrdersWindow : Window
    {
        private readonly variant26Entities model0db = new variant26Entities();
        private readonly MessageHelper _messageHelper = new MessageHelper();
        private User _currentUser;
        public bool IsAdmin => _currentUser?.RoleId == 1;

        public OrdersWindow()
        {
            InitializeComponent();
            DataContext = this;
            _currentUser = CurrentSesion.CurrentUser;
            if (_currentUser == null)
            {
                _messageHelper.ShowError("Пользователь не авторизован");
                Close();
                return;
            }

            // Кнопка добавления видна только администратору
            AddOrderButton.Visibility = IsAdmin ? Visibility.Visible : Visibility.Collapsed;
            LoadOrders();
        }


        private void LoadOrders()
        {
            // Получаем данные из БД без форматирования адреса
            var ordersRaw = model0db.Order
                .Include("PickUpPoint")
                .Include("OrderStatus")
                .Select(o => new
                {
                    o.id,
                    StatusName = o.OrderStatus.Name,
                    o.PickUpPoint.City,
                    o.PickUpPoint.Street,
                    o.PickUpPoint.Building,
                    o.CreationDate,
                    o.DeliveryDate
                })
                .ToList(); 

            // Форматируем адрес уже в памяти (LINQ to Objects)
            var orders = ordersRaw.Select(o => new OrderViewModel
            {
                Id = o.id,
                StatusName = o.StatusName,
                PickUpPointAddress = $"{o.City}, {o.Street}, {o.Building}",
                CreationDate = o.CreationDate,
                DeliveryDate = o.DeliveryDate
            }).ToList();

            OrdersGrid.ItemsSource = orders;

            // Скрываем колонку удаления, если не админ
            if (OrdersGrid.Columns.Count > 5)
                OrdersGrid.Columns[5].Visibility = IsAdmin ? Visibility.Visible : Visibility.Collapsed;
        }

        private void AddOrderButton_Click(object sender, RoutedEventArgs e)
        {
            new AddEditOrderWindow(null).ShowDialog(); 
            LoadOrders(); // обновляем после закрытия
        }

        private void OrdersGrid_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (OrdersGrid.SelectedItem is OrderViewModel order && IsAdmin)
            {
                new AddEditOrderWindow(order.Id).ShowDialog();
                LoadOrders();
            }
        }

        private void DeleteOrderButton_Click(object sender, RoutedEventArgs e)
        {
            if (!IsAdmin)
            {
                _messageHelper.ShowWarning("Только администратор может удалять заказы");
                return;
            }

            var button = sender as Button;
            int orderId = (int)button.Tag;

            // Проверка, можно ли удалить (нет связанных данных, например, товаров в заказе)
            var hasProducts = model0db.Order.Any(po => po.id == orderId);
            if (hasProducts)
            {
                _messageHelper.ShowError("Нельзя удалить заказ, в котором есть товары");
                return;
            }

            if (_messageHelper.ShowQuestion($"Удалить заказ №{orderId}?"))
            {
                try
                {
                    var order = model0db.Order.Find(orderId);
                    if (order != null)
                    {
                        model0db.Order.Remove(order);
                        model0db.SaveChanges();
                        _messageHelper.ShowInfo("Заказ удалён");
                        LoadOrders();
                    }
                }
                catch (Exception ex)
                {
                    _messageHelper.ShowError($"Ошибка: {ex.Message}");
                }
            }
        }

        public Window OwnerWindow { get; set; }


        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            new ProductWindow().Show();
            Close();
        }
    }

    public class OrderViewModel
    {
        public int Id { get; set; }
        public string StatusName { get; set; }
        public string PickUpPointAddress { get; set; }
        public DateTime CreationDate { get; set; }
        public DateTime? DeliveryDate { get; set; }
    }
}