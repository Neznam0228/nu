﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace variant26.DataBase.Statics
{
    public static class CurrentSesion
    {
            public static User CurrentUser { get; set; }
    }
}
