﻿using System;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using variant26.DataBase;
using variant26.DataBase.Helpers;
using variant26.DataBase.Statics;

namespace variant26
{
    public partial class AddEditProductWindow : Window
    {
        private readonly variant26Entities model0db = new variant26Entities();
        private readonly MessageHelper _messageHelper = new MessageHelper();
        private readonly bool _isEditing;
        private Product _product;
        private User _currentUser;

        public AddEditProductWindow(int? id)
        {
            InitializeComponent();
            _currentUser = CurrentSesion.CurrentUser;

            if (id.HasValue) // Режим редактирования
            {
                _isEditing = true;
                _product = model0db.Product.Find(id.Value);
                if (_product == null)
                {
                    _messageHelper.ShowError("Продукт не найден");
                    Close();
                    return;
                }
            }
            else // Режим добавления
            {
                _isEditing = false;
                _product = null;
                // В режиме добавления кнопка удаления не нужна
                DeleteButton.Visibility = Visibility.Collapsed;
            }

            LoadData();
        }

        private void LoadData()
        {
            var units = model0db.Unit.ToList();
            var categories = model0db.Category.ToList();
            var producers = model0db.Producer.ToList();
            var providers = model0db.Provider.ToList();

            ProductUnit.ItemsSource = units;
            ProductUnit.DisplayMemberPath = "Name";
            ProductUnit.SelectedValuePath = "Id";
            if (units.Any()) ProductUnit.SelectedIndex = 0;

            ProductProducer.ItemsSource = producers;
            ProductProducer.DisplayMemberPath = "Name";
            ProductProducer.SelectedValuePath = "Id";
            if (producers.Any()) ProductProducer.SelectedIndex = 0;

            ProductProvider.ItemsSource = providers;
            ProductProvider.DisplayMemberPath = "name";
            ProductProvider.SelectedValuePath = "id";
            if (providers.Any()) ProductProvider.SelectedIndex = 0;

            ProductCategory.ItemsSource = categories;
            ProductCategory.DisplayMemberPath = "Name";
            ProductCategory.SelectedValuePath = "Id";
            if (categories.Any()) ProductCategory.SelectedIndex = 0;

            if (_isEditing)
                FillData();
        }

        private void FillData()
        {
            if (_product == null) return;

            ProductArticle.Text = _product.Article ?? "";
            ProductName.Text = _product.Name ?? "";
            ProductPrice.Text = _product.Price.ToString();
            ProductDiscount.Text = _product.Discount.ToString();
            ProductAmountinStock.Text = _product.AmountinStock.ToString();
            ProductDescription.Text = _product.Description ?? "";
            ProductPhoto.Text = _product.Photo ?? "";

            ProductUnit.SelectedValue = _product.Unitid;
            ProductProducer.SelectedValue = _product.ProducerId;
            ProductProvider.SelectedValue = _product.ProviderId;
            ProductCategory.SelectedValue = _product.CategoryId;
        }

        private void CancelBatton_Click(object sender, RoutedEventArgs e)
        {
            new ProductWindow().Show();
            Close();
        }

        private void SaveBatton_Click(object sender, RoutedEventArgs e)
        {
            if (!ValidateInput()) return;
            if (IsAnyComboBoxEmpty()) return;

            if (_isEditing)
                UpdateProduct();
            else
                CreateProduct();
        }

        private void CreateProduct()
        {
            var product = new Product
            {
                Article = ProductArticle.Text,
                Name = ProductName.Text,
                Price = Convert.ToDecimal(ProductPrice.Text),
                Discount = Convert.ToInt32(ProductDiscount.Text),
                AmountinStock = Convert.ToInt32(ProductAmountinStock.Text),
                Description = ProductDescription.Text,
                Photo = ProductPhoto.Text,
                Unitid = GetSelectedId(ProductUnit),
                ProducerId = GetSelectedId(ProductProducer),
                ProviderId = GetSelectedId(ProductProvider),
                CategoryId = GetSelectedId(ProductCategory)
            };

            try
            {
                model0db.Product.Add(product);
                model0db.SaveChanges();
                _messageHelper.ShowInfo("Продукт успешно создан");
                CancelBatton_Click(null, null);
            }
            catch (Exception ex)
            {
                Exception innerEx = ex.InnerException;
                while (innerEx?.InnerException != null)
                    innerEx = innerEx.InnerException;
                _messageHelper.ShowError($"Ошибка при сохранении: {innerEx?.Message ?? ex.Message}");
            }
        }


        private void UpdateProduct()
        {
            if (_product == null) return;

            _product.Article = ProductArticle.Text;
            _product.Name = ProductName.Text;
            _product.Price = Convert.ToDecimal(ProductPrice.Text);
            _product.Discount = Convert.ToInt32(ProductDiscount.Text);
            _product.AmountinStock = Convert.ToInt32(ProductAmountinStock.Text);
            _product.Description = ProductDescription.Text;
            _product.Photo = ProductPhoto.Text;
            _product.Unitid = GetSelectedId(ProductUnit);
            _product.ProducerId = GetSelectedId(ProductProducer);
            _product.ProviderId = GetSelectedId(ProductProvider);
            _product.CategoryId = GetSelectedId(ProductCategory);

            try
            {
                model0db.SaveChanges();
                _messageHelper.ShowInfo("Продукт успешно изменён");
                CancelBatton_Click(null, null);
            }
            catch (Exception ex)
            {
                _messageHelper.ShowError($"Ошибка при сохранении: {ex.Message}");
            }
        }

        // Удаление товара
        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            // Только администратор может удалять
            if (_currentUser?.RoleId != 1)
            {
                _messageHelper.ShowWarning("Только администратор может удалять товары");
                return;
            }

            if (_product == null) return;

            // Проверка наличия в заказах (используем универсальный Set<T>)
            bool inOrder = model0db.Set<Order>().Any(po => po.id == _product.id);
            if (inOrder)
            {
                _messageHelper.ShowError("Нельзя удалить товар, который присутствует в заказах");
                return;
            }

            if (MessageBox.Show($"Удалить товар \"{_product.Name}\"?", "Подтверждение",
                    MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    model0db.Product.Remove(_product);
                    model0db.SaveChanges();
                    _messageHelper.ShowInfo("Товар удалён");
                    // Возвращаемся к списку товаров
                    new ProductWindow().Show();
                    Close();
                }
                catch (Exception ex)
                {
                    _messageHelper.ShowError($"Ошибка при удалении: {ex.Message}");
                }
            }
        }

        private void ProductCategory_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
        }

        private int GetSelectedId(ComboBox combo)
        {
            if (combo.SelectedItem == null) return 0;
            dynamic item = combo.SelectedItem;
            return item.id;
        }

        private bool IsAnyComboBoxEmpty()
        {
            if (ProductUnit.SelectedItem == null) { _messageHelper.ShowError("Выберите единицу измерения"); return true; }
            if (ProductProducer.SelectedItem == null) { _messageHelper.ShowError("Выберите производителя"); return true; }
            if (ProductProvider.SelectedItem == null) { _messageHelper.ShowError("Выберите поставщика"); return true; }
            if (ProductCategory.SelectedItem == null) { _messageHelper.ShowError("Выберите категорию"); return true; }
            return false;
        }

        private bool ValidateInput()
        {
            var errors = new StringBuilder();
            if (string.IsNullOrWhiteSpace(ProductArticle.Text)) errors.AppendLine("• Артикул не заполнен");
            if (string.IsNullOrWhiteSpace(ProductName.Text)) errors.AppendLine("• Название не заполнено");
            if (!decimal.TryParse(ProductPrice.Text, out decimal price) || price < 0) errors.AppendLine("• Цена должна быть положительным числом");
            if (!int.TryParse(ProductDiscount.Text, out int discount) || discount < 0 || discount > 100) errors.AppendLine("• Скидка должна быть целым числом от 0 до 100");
            if (!int.TryParse(ProductAmountinStock.Text, out int amount) || amount < 0) errors.AppendLine("• Количество на складе должно быть целым неотрицательным числом");
            if (string.IsNullOrWhiteSpace(ProductDescription.Text)) errors.AppendLine("• Описание не заполнено");
            if (errors.Length > 0) { _messageHelper.ShowError($"Исправьте ошибки:\n{errors}"); return false; }
            return true;
        }
    }
}